import React from "react";

const Solutions = () => {
  return (
    <div>
      <h1>
        {" "}
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nam
        praesentium culpa nulla, aperiam laboriosam dolorum magnam veritatis,
        quisquam id necessitatibus, itaque eligendi dolores sit ducimus error
        quam. Aliquid, maxime veritatis!
      </h1>
    </div>
  );
};

export default Solutions;
