import React from 'react'

const Careers = () => {
  return (
    <div>
   <h1></h1>   
    </div>
  )
}

export default Careers
