// import React from "react";
// // import { Link } from "react-router-dom";
// import Link from "next/link";
// const Navbar = () => {
//   return (
//     <div className="bg-[#0A0A0A] max-w-[1440px] border border-red-500 mx-auto">
//       <div className="fixed top-0 left-0 w-full z-50 bg-[#0A0A0A]">
//         <div className="flex items-center justify-between px-6 py-4 max-w-[1280px] mx-auto">
//           <div className="text-white font-bold">Logo</div>
//           <div className="flex items-center space-x-6 text-white">
//             <Link href="/Solutions">Solutions</Link>
//             <Link href="/Services">Services</Link>
//             <Link href="/Industries">Industries</Link>
//             <Link href="/Company">Company</Link>
//             <Link href="/Careers">Careers</Link>
//           </div>
//           <button className="bg-white text-black px-4 py-2 rounded-lg">
//             Contact us
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Navbar;
// "use client";
// import Link from "next/link";

// import React, { useState } from "react";
// // import { Link } from "react-router-dom";

// const Navbar = () => {
//   const [click, setClick] = useState(false);
//   const toggleMenu = () => setClick(!click);

//   const navItems = [
//     { name: "Solutions", path: "/Solutions" },
//     { name: "Services", path: "/Services" },
//     { name: "Industries", path: "/Industries" },
//     { name: "Company", path: "/Company" },
//     { name: "Careers", path: "/Careers" },
//   ];

//   return (
//     <nav className="fixed top-0 left-0 w-full z-50 bg-amber-500 h-[73px] max:w-[1420px]  text-white">
//       <div className="flex gap-6 items-center justify-between mx-[73px] my-[24px]  ">
//         <div className="text-2xl font-bold">Logo</div>

//         {/* Desktop Menu */}
//         <ul className="hidden lg:flex space-x-10 items-center text-[18px] ">
//           {navItems.map((item) => (
//             <li key={item.name} className="hover:text-[#FF7800] cursor-pointer">
//               <Link href={item.path}>{item.name}</Link>
//             </li>
//           ))}
//           <button className="bg-white text-black px-6 py-2  rounded-lg hover:bg-gray-200 ml-[200px] transition">
//             Contact Us
//           </button>
//         </ul>

//         {/* Mobile Button */}
//         <div className="lg:hidden text-2xl cursor-pointer" onClick={toggleMenu}>
//           {click ? "×" : "☰"}
//         </div>
//       </div>

//       {/* Mobile Menu */}
//       {click && (
//         <div className="lg:hidden bg-slate-950 w-full px-6 pb-6">
//           <ul className="flex flex-col text-center space-y-4 text-[18px]">
//             {navItems.map((item) => (
//               <li key={item.name} className="py-2 hover:bg-slate-800 rounded">
//                 <Link href={item.path} onClick={() => setClick(false)}>
//                   {item.name}
//                 </Link>
//               </li>
//             ))}
//             <button className="mt-4 bg-white text-black px-6 py-2 rounded-lg hover:bg-gray-200 transition">
//               Contact Us
//             </button>
//           </ul>
//         </div>
//       )}
//     </nav>
//   );
// };

// export default Navbar;

"use client";
import Link from "next/link";
import React, { useState } from "react";

const Navbar = () => {
  const [click, setClick] = useState(false);
  const toggleMenu = () => setClick(!click);

  const navItems = [
    { name: "Solutions", path: "/Solutions" },
    { name: "Services", path: "/Services" },
    { name: "Industries", path: "/Industries" },
    { name: "Company", path: "/Company" },
    { name: "Careers", path: "/Careers" },
  ];

  return (
    <nav className="fixed top-0 left-0  z-50 bg-[#1A0D02] h-20 w-[1420px]  ">
      <div className="flex gap-6 items-center justify-between mx-[73px] mt-[24px] mb-[24px]  font-normal font-['Inter']">
        <div className="text-[#FF7800] text-2xl font-bold">Logo</div>

        {/* Desktop Menu */}
        <ul className="hidden lg:flex space-x-10 items-center justify-center  text-[18px] ">
          {navItems.map((item) => (
            <li
              key={item.name}
              className="hover:text-[#FF7800] transition cursor-pointer text-zinc-100 text-sm font-normal tracking-wide"
            >
              <Link href={item.path}>{item.name}</Link>
            </li>
          ))}

          <button
            className="bg-white text-black outline-[0.74px] outline-offset-[-0.74px] courser-pointer
           rounded-lg hover:text-[#FF7800] w-24 h-8 ml-[200px] transition"
          >
            Contact Us
          </button>
        </ul>

        {/* Mobile Menu Button */}
        <div
          className="lg:hidden text-2xl cursor-pointer text-white"
          onClick={toggleMenu}
        >
          {click ? "×" : "☰"}
        </div>
      </div>

      {/* Mobile Menu */}
      {click && (
        <div className="lg:hidden bg-slate-950 w-full px-6 pb-6">
          <ul className="flex flex-col text-center space-y-4 text-[18px]">
            {navItems.map((item) => (
              <li key={item.name} className="py-2 hover:bg-slate-800 rounded">
                <Link href={item.path} onClick={() => setClick(false)}>
                  {item.name}
                </Link>
              </li>
            ))}
            <button className="mt-4 bg-white text-black px-6 py-2 rounded-lg hover:bg-gray-200 transition">
              Contact Us
            </button>
          </ul>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
