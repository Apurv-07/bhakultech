import React from 'react'

const Industrise = () => {
  return (
    <div>
     <h1></h1> 
    </div>
  )
}

export default Industrise
